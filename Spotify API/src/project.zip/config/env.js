import { config } from "dotenv";

config({
    path: `.env.${process.env.NODE_ENV || 'development'}`
});

export const {
    PORT,
    NODE_ENV,
    DB_URI,
    JWT_SECRET,
    JWT_EXPIRES_IN,
    PRIVATE_KEY,
    PUBLIC_KEY,
    URL_ENDPOINT
} = process.env;